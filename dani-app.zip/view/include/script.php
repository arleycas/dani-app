<!---------- Aqui van las etiquetas script --------->

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<!-- Fontawesome -->
<script src="https://kit.fontawesome.com/074be1019d.js" crossorigin="anonymous"></script>

<!-- Sweet Alert 2 -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="<?php echo SERVERURL ?>view/js/alerts.js"></script>